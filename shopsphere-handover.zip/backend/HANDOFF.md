# Person C → Person D

Backend API is up and stable. Everything below is what you need to build the
dashboard without reading a line of my code.

**Base URL:** `http://localhost:8000`
**Interactive docs (live, try-it-out):** http://localhost:8000/docs
**Raw OpenAPI spec:** http://localhost:8000/openapi.json
**WebSocket:** `ws://localhost:8000/ws/live-updates`

CORS is already open for `http://localhost:5173` (Vite) and `http://localhost:3000`.
If you run on another port, add it to `CORS_ORIGINS` in `app/config.py` — don't
fight it in the browser.

---

## 1. What I built

One FastAPI service that is the only thing talking to all four databases. Each
endpoint reads from whichever database is the right home for that question:

| Endpoint | Database | Why that one |
|---|---|---|
| `GET /api/revenue` | Redis | Pre-aggregated counters, instant read |
| `GET /api/orders` | MongoDB | Full order documents, flexible shape |
| `GET /api/active-users` | Redis | Set cardinality, sub-millisecond |
| `GET /api/top-products` | MongoDB | Aggregation over order documents |
| `GET /api/click-activity` | Cassandra | High-volume time-ordered click log |
| `GET /api/user-activity` | Cassandra + MongoDB | Clicks vs orders |
| `GET /api/recommendations` | Neo4j | Graph traversal, "also bought" |
| `GET /api/health` | all four | One call tells you what's down |
| `WS /ws/live-updates` | Redis | Server push, no polling from you |

That table is the whole polyglot-persistence argument in one place — it's
worth putting on a slide.

---

## 2. Endpoints and exact responses

### `GET /api/health`
Call this first whenever anything looks broken.
```json
{
  "api": "up",
  "databases": {
    "mongodb": "up",
    "redis": "up",
    "cassandra": "down: NoHostAvailable",
    "neo4j": "up"
  }
}
```
The API boots and serves whatever it can even if a database is down — a dead
Cassandra only breaks the two click endpoints, not the whole dashboard.

### `GET /api/revenue`
```json
{ "revenue_today": 15876.40, "currency": "INR", "orders_today": 342, "source": "redis" }
```
`source` is `"redis"` normally, `"mongodb"` if the Redis counters are missing.

### `GET /api/orders?limit=10`
```json
{
  "orders": [
    {
      "order_id": "ORD5690",
      "product_id": "P14",
      "product_name": "Monitor",
      "user_id": "USR816",
      "amount": 462.82,
      "status": "placed",
      "timestamp": "1981-07-09T14:52:36",
      "received_at": "2026-09-21T10:24:11Z"
    }
  ],
  "count": 1
}
```
`limit` accepts 1–100, defaults to 10.

### `GET /api/active-users`
```json
{ "active_users": 87, "as_of": "2026-09-21T10:25:00Z" }
```

### `GET /api/top-products?limit=5`
```json
{
  "top_products": [
    { "product_id": "P14", "name": "Monitor", "orders": 128, "revenue": 41233.50 },
    { "product_id": "P33", "name": "P33", "orders": 96, "revenue": 30880.10 }
  ]
}
```
I added `revenue` on top of the contract shape — it's additive, ignore it if
you don't need it.

### `GET /api/click-activity`
```json
{
  "total_clicks": 1240,
  "by_page": [
    { "page": "home", "clicks": 512 },
    { "page": "product_detail", "clicks": 340 },
    { "page": "cart", "clicks": 236 },
    { "page": "checkout", "clicks": 152 }
  ],
  "scanned_rows": 1240,
  "truncated": false
}
```
This one is new — it wasn't in the contract. It's the honest version of click
data and makes a great funnel bar chart (`home → product_detail → cart →
checkout`). Please use it; see the caveat on `/api/user-activity` below.

### `GET /api/user-activity?product_id=P14`
```json
{ "product_id": "P14", "clicks_today": 340, "orders_today": 22, "conversion_rate": 0.0647, "approximate": true }
```
**Read the caveat in section 4 before you put this on screen.**

### `GET /api/recommendations?product_id=P14&limit=5`
```json
{
  "product_id": "P14",
  "name": "Monitor",
  "also_bought": [
    { "product_id": "P19", "name": "Speaker", "strength": 34 },
    { "product_id": "P33", "name": "P33", "strength": 21 }
  ]
}
```
`strength` = number of distinct users who bought both. An empty `also_bought`
is a normal answer for a product nobody has co-purchased yet — render an empty
state, don't treat it as an error.

### Errors
Any failure returns the contract's error shape with a non-200 status:
```json
{ "error": "cassandra unavailable: NoHostAvailable" }
```
`503` means a database is down or still starting; `422` means a bad query
parameter (FastAPI validates these for you).

---

## 3. WebSocket — `ws://localhost:8000/ws/live-updates`

On connect you get one snapshot immediately, so your counters are never blank:
```json
{ "event": "snapshot", "revenue_today": 15876.40, "orders_today": 342, "active_users": 87, "as_of": "2026-09-21T10:25:00Z" }
```
After that, a message **only when a number actually changed** (checked every 2s):
```json
{ "event": "new_order", "revenue_today": 16339.22, "orders_today": 343, "active_users": 88, "as_of": "2026-09-21T10:25:02Z" }
```
`event` is `"snapshot"` on connect, `"new_order"` when the order count went up,
`"tick"` when only revenue or active users moved. Every message carries all
four fields, so you can treat them identically and just overwrite state.

Minimal React usage:
```js
useEffect(() => {
  const ws = new WebSocket("ws://localhost:8000/ws/live-updates");
  ws.onmessage = (e) => setLive(JSON.parse(e.data));
  ws.onclose = () => { /* optional: retry after a few seconds */ };
  return () => ws.close();
}, []);
```
You don't need to send anything — it's push-only. Add a reconnect timer before
the demo; if you restart my server mid-demo the socket dies silently otherwise.

---

## 4. Data quirks you must know about (these will bite you)

These come from what Person A's generator actually emits. None of them are
bugs in my layer — they're real constraints, and each one is a good answer in
the viva if an evaluator asks.

1. **Timestamps are fake and non-chronological.** The generator uses
   `faker.iso8601()`, which produces random dates across decades — I've seen
   1981 and 2012 in the same minute of runtime. **Never sort or filter on
   `timestamp`, and never build a "last hour" chart from it.** Use
   `received_at` instead: I derive it from the MongoDB ObjectId, which has the
   real insertion time baked in, so it is genuine processing order.

2. **`revenue_today` isn't really "today".** It's an all-time running total
   from Redis, for the same reason as #1 — there's no trustworthy date to
   window on. Label it "Total Revenue" on the dashboard, not "Today".

3. **Most products have no name.** Person B seeded P10–P19 only; the generator
   emits up to P50. Any unseeded id returns its own id as the name (`"P33"`).
   Either accept it, or ask Person B to extend `seed_products.py` to P50 —
   one list edit, five minutes, and the demo looks much better.

4. **`status` is always `"placed"`.** The generator emits no order lifecycle.
   I kept the field because it was in the contract and your table probably
   binds to it, but don't build a status filter — every row is identical.

5. **`/api/user-activity` conversion rate is approximate.** Click events carry
   a page *category* (`product_detail`), never a `product_id`, so no click can
   be attributed to a specific product. `orders_today` is exact for that
   product; `clicks_today` is the site-wide `product_detail` count. The
   response always includes `"approximate": true` — please show a small
   asterisk or tooltip next to it rather than presenting it as a real
   conversion rate. The proper fix is Person A adding `product_id` to click
   events; I've written that up as future work in the report.

6. **Redis float drift.** `orders:revenue_today` accumulates `INCRBYFLOAT`
   error (Person B measured `15876.39999999999999947`). I round to 2dp at the
   API boundary, so what you receive is already clean.

7. **Cassandra totals are a capped scan.** Cassandra can't aggregate across
   partitions cheaply, so click counts scan up to 50,000 rows and cache for
   15s. If `truncated` is `true`, the numbers are a sample — at demo volumes
   it'll always be `false`.

---

## 5. How to run it

Assumes Person B's stack is already up. From the repo root:

```bash
# 1. Databases + Kafka (repo root, not a subfolder - see Person B's notes)
docker compose up -d
docker ps                       # expect 6 containers
# wait ~45s for Cassandra to actually accept connections

# 2. Install backend deps
cd backend
pip install -r requirements.txt

# 3. Run the API
uvicorn app.main:app --reload --port 8000
```

Open http://localhost:8000/docs — Swagger is auto-generated, every endpoint has
a **Try it out** button, and the example responses above are all in there.

For live data you also need Person A's producer and Person B's consumer
running, in two more terminals:
```bash
cd producer          && python kafka_producer.py
cd stream_processor  && python consumer.py
```
Without them the API still works — it just reports whatever is already stored.

### Testing
```bash
python smoke_test.py    # hits every endpoint, checks keys, exits non-zero on failure
python ws_test.py       # prints live pushes as they arrive (pip install websockets)
```
Or by hand:
```bash
curl http://localhost:8000/api/health
curl "http://localhost:8000/api/orders?limit=3"
curl "http://localhost:8000/api/recommendations?product_id=P14"
```

### Config
Everything (hosts, ports, credentials, CORS, poll interval) is in
`app/config.py` and overridable by environment variable — see `.env.example`.
If you containerise the API in `docker-compose.yml`, set `MONGO_URI`,
`REDIS_HOST`, `CASSANDRA_HOST` and `NEO4J_URI` to the **service names**
(`mongodb`, `redis`, `cassandra`, `neo4j`) instead of `localhost`. No code
changes needed. See section 7 for the compose block.

---

## 6. File layout

```
backend/
  app/
    main.py            FastAPI app, CORS, /api/health, WebSocket route
    config.py          every setting, env-overridable
    db.py              lazy clients for all 4 databases + health pings
    services.py        the actual queries (shared by REST and WebSocket)
    models.py          response schemas -> these generate the Swagger examples
    ws.py              one background loop, broadcasts to all clients
    routers/
      metrics.py       /api/revenue, /api/active-users
      orders.py        /api/orders
      products.py      /api/top-products, /api/click-activity, /api/user-activity
      recommendations.py
  requirements.txt
  smoke_test.py
  ws_test.py
  .env.example
  HANDOFF.md
```

Two deliberate decisions worth defending in the viva:

- **Nothing connects at import time.** Cassandra takes ~45s to become ready;
  if I connected on startup the whole API would crash-loop while it warms up.
  Clients connect lazily on first use, so the API boots instantly and degrades
  per-endpoint instead of all at once.
- **One WebSocket loop, not one per client.** The stream processor doesn't
  notify me — it writes straight to the databases. Rather than couple our two
  services, I poll the cheap Redis counters once every 2s and push to all
  connected clients only on change. Fifty open dashboards cost the same as one.

---

## 7. Optional: add the backend to docker-compose.yml

Your call as DevOps lead — running uvicorn on the host is fine for the demo.
If you want one-command startup, add a `Dockerfile` in `backend/`:

```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY app ./app
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

and this service to the root compose file:

```yaml
  backend:
    build: ./backend
    container_name: backend
    depends_on: [mongodb, redis, cassandra, neo4j]
    ports:
      - "8000:8000"
    environment:
      MONGO_URI: mongodb://mongodb:27017/
      REDIS_HOST: redis
      CASSANDRA_HOST: cassandra
      NEO4J_URI: bolt://neo4j:7687
```

---

## 8. Confirmation checklist

- [x] FastAPI service running on :8000, all 7 data endpoints implemented
- [x] Swagger auto-generated at `/docs`, every endpoint documented with examples
- [x] WebSocket at `/ws/live-updates` pushing snapshot + change events
- [x] All four databases read from, each for what it's best at
- [x] Error shape matches the contract (`{"error": "..."}` + non-200)
- [x] CORS enabled for the Vite dev server
- [x] Graceful degradation — one dead database doesn't take down the API
- [x] `smoke_test.py` covers every endpoint
- [ ] Person D: confirm the dashboard binds to these shapes and the socket reconnects

---

## 9. Changes I made to `api-contract.md`

The contract was written on Day 1 before anyone had seen real data. Four
things in it don't exist in the pipeline, so I amended it rather than fake
them. Full updated contract is in the repo root; the diff:

| Contract said | Reality | What I did |
|---|---|---|
| Order has `product_name` | Generator emits `product_id` only | Return both; name falls back to the id |
| Order has `status` | No lifecycle in the generator | Kept as constant `"placed"`, documented |
| `timestamp` is usable | Random fake dates across decades | Added `received_at`, the real one |
| `/api/user-activity` per-product clicks | Clicks have no `product_id` | Approximated + `approximate: true` flag |
| `also_bought[].strength` | — | Unchanged, now sourced from real Neo4j data |
| — | — | **Added** `/api/health` and `/api/click-activity` |

One more thing I found while wiring Neo4j: the recommendation Cypher in
Person B's `stream_processor/HANDOFF.md` matches `(:Product {product_id: $pid})`,
but `neo4j_writer.py` actually creates nodes as `(:Product {id: ...})`. The
documented query returns zero rows against the real graph. My endpoint uses
`{id: $pid}` and works — worth telling Person B so their doc gets fixed before
the report goes out.
