"""
WebSocket check. Needs `pip install websockets`.

    python ws_test.py

Expect one "snapshot" message immediately, then a message every time the
stream processor changes revenue / order count / active users. If you see the
snapshot but nothing after, the producer or consumer is not running.
"""

import asyncio
import json

import websockets

URL = "ws://localhost:8000/ws/live-updates"


async def main():
    async with websockets.connect(URL) as ws:
        print(f"connected to {URL} - waiting for pushes (Ctrl+C to stop)\n")
        while True:
            msg = json.loads(await ws.recv())
            print(
                f"[{msg['event']:9}] revenue={msg['revenue_today']:>12} "
                f"orders={msg['orders_today']:>5} active_users={msg['active_users']:>4}"
            )


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nstopped.")
